package com.example.app.domain.common.dto;

import com.example.app.type.ROLE;

public class UserDto {
	private String id;
	private String password;
	private String username;
	private ROLE role;
	
	private boolean islocked;
	
}
