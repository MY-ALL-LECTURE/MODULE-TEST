package View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Controller.FrontController;
import Domain.Item.Dto.Item;
import View.TUI.TUI;


public class Index {
	public static void main(String[] args) {
	
		new TUI().MainMenu();

	}
}
