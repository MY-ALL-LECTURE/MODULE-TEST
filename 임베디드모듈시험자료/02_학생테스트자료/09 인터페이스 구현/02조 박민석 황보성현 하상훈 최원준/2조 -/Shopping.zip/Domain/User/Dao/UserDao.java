package Domain.User.Dao;

import Domain.DB.Crud;
import Domain.User.Dto.User;

public interface UserDao extends Crud<User, String>{
}